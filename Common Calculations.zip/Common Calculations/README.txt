Common Calculations
by Christian Tobar 
October 24, 2021
contact: gatewaycityca@yahoo.

Thank you for downloading Common Calculations!

Please note that Common Calculations is for DOS 3.3 - it will mostly likely NOT run on ProDos!

So why make a calculating program for an ancient 8-bit computer when there are plenty of modern programs available? Well, first of all, I don't think I've seen a modern application that can do all THIS in one place. Common Calculations has a LOT of features which I think you will find handy!  

Common Calculations can do pretty much every calculation you would typically need: Calculate percentages. Geometry calculations to easily find area, perimeter and volume. Convert US and Metric measurements (you can even convert Fahrenheit to Kelvin!). Convert fluid measurements. Common Calculations is essentially a mathematical Swiss Army knife! I could be wrong, but I don't think even a modern program has this many calculations available in one place. If you're using a real Apple II computer, you can also print your results. 

USING WITH A REAL APPLE II COMPUTER
If you want to use the program with an actual vintage Apple II computer (which I definitely recommend!), you have 2 options to transfer it from your modern computer to the Apple II. You can use a serial or serial-to-usb cable and send the text from the included BASIC code with a serial connection to the Apple II.  OR you can use the included .wav sound file to transfer the program by connecting an audio cable to the Apple II "casette input" jack. The wav file includes a utility which will automatically save the BASIC program onto a floppy disk. Insert a blank disk into the Apple II disk drive, and type "LOAD" on the Apple II. Then play the .wav file.
The program will be copied onto the disk as "CALC." 

If you prefer, I can also send you a floppy disk with the program, for $10. Email me if you're interested.

USING WITH AN EMULATOR
If you want to run the program on a modern computer, you will need an Apple II emulator. AppleWin is the only one I've personally used. Just load the disk image file named "Common Calculations.do" on the emulator. I tested the program on AppleWin and everything seems to work correctly. To run the program, just enter "RUN CALC" as you would on a real Apple II computer.

If you have any questions or suggestions, please feel free to email me!

