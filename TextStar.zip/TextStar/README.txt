TextStar
by Christian Tobar 
October 28, 2021
contact: gatewaycityca@yahoo.

Thank you for downloading TextStar!

Please note that TextStar is for DOS 3.3 - it will mostly likely NOT run on ProDos!

TextStar is a bare bones simple text editing program. The name is kind of a play on words of the famous word processing program, WordStar. It's super easy to use and can come in handy when you just want to quickly view and edit text files. You can easily save, load, and print text files. The program does have some limitations, which will be discussed.

This is actually my first attempt at making a text editing program. I created it after I found some old floppy disks with an Apple II computer I bought. The disks had a few mysterious files and I didn't know what program used them. So I wanted to see if it was possible to make a simple program to open any file and display the contents as text. It worked! As far as I can tell, TextStar will open any file except binary files and Applesoft BASIC files. It has error handling so if it is unable to read a file, it will simply stop loading and return to the Main Menu.  

USING WITH A REAL APPLE II COMPUTER
If you want to use the program with an actual vintage Apple II computer (which I definitely recommend!), you have 2 options to transfer it from your modern computer to the Apple II. You can use a serial or serial-to-usb cable and send the text from the included BASIC code with a serial connection to the Apple II.  OR you can use the included .wav sound file to transfer the program by connecting an audio cable to the Apple II "casette input" jack. The wav file includes a utility which will automatically save the BASIC program onto a floppy disk. Insert a blank disk into the Apple II disk drive, and type "LOAD" on the Apple II. Then play the .wav file. This will copy 2 files onto the disk - the TEXTSTAR program itself, and a sample text file called "SAMPLE.TXT." To run the program, enter "RUN TEXSTAR"

If you prefer, I can also send you a floppy disk with the program, for $10. Email me if you're interested.

USING WITH AN EMULATOR
If you want to run the program on a modern computer, you will need an Apple II emulator. AppleWin is the only one I've personally used. Just load the disk image file named "Texstar.do" on the emulator. I tested the program on AppleWin and everything seems to work correctly. To run the program, just enter "RUN TEXTSTAR" as you would on a real Apple II computer.

WRITING A TEXT FILE
On the Main Menu, you can enter 1 to view and edit a text document. This will display the Text Editing screen. (It may take a couple of seconds to open). You will notice that the screen is divided into two parts. The upper part shows the text that has been added to the current document so far. You will see a caret idicator which points to the line you're currently editing. When you start a new text document, it will indicate the first line of text. As you enter more lines, the indicator will move down. 
   
The lower part of the Text Editing screen is where you type the line that you want to add to the text document. You will see a caret prompt to enter your text. Type the text that you want to add and press RETURN. Whenever you add a line of text, the screen will be re-drawn and the text document will be updated. It may take a second or two to redraw the screen. You will also see how much free memory is available, the line number that you are currently editing, and the "screen" that you are currently viewing. When the lines of text reach the bottom edge of the display area, any new text you add will be displayed in the next "screen." (The "screen number" is discussed in the Navigating section).   

Note that at the moment unfortunately the program does NOT accept commas. This is because each line of text is treated as a string variable, and BASIC ignores commas when you input the value for a single string variable. (A future version of the program will fix this).  

NAVIGATING AND EDITING LINES
There are several commands you can type at the text editing prompt. To go back to the Main Menu, enter "*M" (without quotes). Your text document will stay in memory, and you can view it again at any time by entering 1 from the Main Menu. 

You can go back and change any line of text in the document. At the prompt in the Text Editing screen, enter "*PL" and press RETURN to move to the previous line (again, without quotes). The screen will be re-drawn and you will see the caret idicator move up one line. To move down to the next line, enter "*NL" and press RETURN. Once the indicator is on the line that you want to change, type the text as you want it. Note however that there is no feature to insert text. In order to change a line of text, you must retype it.

As mentioned earlier, when the lines of text reach the bottom edge of the display area, any new text you add will automatically be moved to the next "screen." You can move backward and forward through the screens by entering commands at the prompt in the Text Editing screen. To view the next screen, enter "*NS" at the prompt. Enter "*PS" to go back to the previous screen.

IMPORTANT NOTE! When you view a different screen, the current line you're editing will NOT automatically advance! Enter "*FL" to select the first line of text on the screen you're viewing. You can then move up or down through the lines of text on that screen by using the *PL and *NL commands. To avoid confusion, be sure to look at the line number you're editing.

The screen number has no bearing on actual page number. TextStar doesn't really account for pages. You can have a maximum of 100 lines of text total. This is roughly equivalent to 2 pages. Different screens are used simply because there is no feature to "scroll" through the text document, and instead the text document is displayed in sections.        

SAVING TEXT FILES
It's easy to save the text file you've edited. From the Main Menu, enter 2 for "Save Current Document." This will show a prompt asking for a file name. The Apple II computer isn't very picky about file names, so you can pretty much name your text file whatever you want. Extensions are optional. However, I would recommend using an extension of ".TXT" just so you can easily identify your text files later. So mabe name the file something like "TEXT1.TXT" 
You can cancel saving a file by just leaving the prompt blank.

RESETTING THE TEXT DOCUMENT
If you want to start over with a new text document, enter 3 from the Main Menu. But be careful! This will completely erase the document from the memory! This can't be undone! The program will warn you first and ask if you want to proceed with resetting the document.

LOADING TEXT FILES
It's also very easy to load a text file you saved to a floppy disk. From the Main Menu, enter 4 for "Load Document." This will display the contents of the floppy disk and show a prompt for the file you want to load. After you load a file, you will be take back to the Main Menu. The loaded text file will be in memory, simply enter 1 from the Main Menu to view it. 

PRINTING TEXT DOCUMENTS
To print the current document, enter 5 from the Main Menu. Be sure you have the right slot selected for your printer interface card. By default, the program will use Slot 1. If you need to change the slot number, enter 6 from the Main Menu. (Note however that TextStar can't change any settings such as Baud rate, Data bits, etc. You must have your card and printer already configured beforehand). 

The program will remind you to check that your printer is connected and ready to print. You can proceed with printing or cancel and return to the Main Menu.

After the document is finished printing, you will be taken back to the Main Menu.

SETTING 40 OR 80 COLUMNS
TextStar doesn't really care whether you have a 40 column or 80 column display. In the Text Editing screen, it just adds lines of text exactly as you type them. However, if you are using an Apple II computer with an 80 column display, some of the menus might look better if you set the program to 80 columns. To do this, enter 8 from the Main Menu. This will display another menu with several options. You can ignore the "Wizard-80" option. I originally wrote the TextStar program on an Apple II+ computer, and the "Wizard-80" is one of the very few 80 column cards that works with the Apple II+. (Most of them can only be used in an Apple IIe). It seems like it is somewhat rare, but if you do happen to have one installed, enter 2 to enable it.

If your Apple II is already displaying in 80 columns with a different card, enter 3. Again, this doesn't really have any significance in how the program functions, it will just format some of the menus to look better on your screen.

HELP SCREEN
There is a help screen, which will show a reminder of the commands you can enter. From the Main Menu, enter 7 to view the Help screen.

KNOWN ISSUES AND LIMITATIONS
As mentioned earlier, TextStar does NOT accept commas when entering text. I will try to fix this in a future version of the program. All other punctuation seems to work. Another limitation is that the maximum number of lines you can have in a text document is 100. This is about 2 pages, or maybe slightly longer. However, you could also just split up a longer document into multiple text files on a disk.  

I think that should cover all the basics! I hope you enjoy using TextStar!    

If you have any questions or suggestions, please feel free to email me!
