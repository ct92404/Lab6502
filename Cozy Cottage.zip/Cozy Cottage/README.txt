Cozy Cottage 
by Christian Tobar 
October 23, 2021
contact: gatewaycityca@yahoo.

Thank you for downloading Cozy Cottage!

Please note that Cozy Cottage is for DOS 3.3 - it will mostly likely NOT run on ProDos!

This is a neat little program to demonstrate the graphics and colors possible in low resolution mode (GR). The premise is that you have a small cottage in the countryside, and you can customize it by changing the colors, planting trees, adding furniture in the living room, etc. There are a LOT of options. Build your dream home!

I wrote Cozy Cottage entirely on a real Apple II+ computer. 

This was actually the first program I wrote for the Apple II, after I became interested in vintage 8-bit computers in recent years. (I was very young during the 8-bit era of the early 1980's and my only experience with using computers during that time was with playing educational games at school, such as "Oregon Trail.")  I first wrote Cozy Cottage a few years ago, and made improvements to it over time. It was a lot of fun to make and is still one of my favorite programs!

USING WITH A REAL APPLE II COMPUTER
If you want to use the program with an actual vintage Apple II computer (which I definitely recommend!), you have 2 options to transfer it from your modern computer to the Apple II. You can use a serial or serial-to-usb cable and send the text from the included BASIC code with a serial connection to the Apple II.  OR you can use the included .wav sound file to transfer the program by connecting an audio cable to the Apple II "casette input" jack.  The wav file includes a utility which will automatically save the BASIC program onto a floppy disk. Insert a blank disk into the Apple II disk drive, and type "LOAD" on the Apple II. Then play the .wav file. Note that there are 2 versions of the .wav file. One will format the disk first before the program is copied. The other SHOULDN'T format the disk, but I would suggest you use a blank disk to be safe! 

If you prefer, I can also send you a floppy disk with the program, for $10. Email me if you're interested.

USING WITH AN EMULATOR
If you want to run the program on a modern computer, you will need an Apple II emulator. AppleWin is the only one I've personally used. Just load the disk image file named "Cozy Cottage.do" on the emulator. I tested the program on AppleWin and everything seems to work correctly. If you save or load houses, the files will just be added into the disk image and can be accessed within the Cozy Cottage program as if you were using a real floppy disk.
 
USING COZY COTTAGE  
Most of the options in the menus are pretty straight-forward and self-explanatory, but here are some helpful tips:

PLACING OBJECTS
When you place objects either outside in the landscaping or in the living room, the house will be re-drawn with a small black square cursor or "pointer." This indicates where you will be placing the object, and you can move it around on the screen by typing the keys shown on the menu below.  Do NOT use the arrow keys on the keyboard! After you place the object (or cancel), the house will be redrawn with whatever new object you placed. Note that any object can also be removed either from the landscaping or the living room - just select "Remove items" from the respective location's menu. 

At the moment, only 2 locations are available: outside and the living room. More rooms might be added later in a future version of the program.

SAVING YOUR HOUSE
It's very simple to save your house. First, go to the exterior view of the house (select "Go outside" if you're in the living room). Then select "Menu." This will display the screen that is considered the "Main Menu" of the program, where most of the more important options are, such as saving or loading houses, resetting the house, etc. Select "Save current house." You will be shown another screen and prompted to enter a file name. If you want to cancel, just leave it blank and press RETURN and no action will be taken. If you decide to save, you can pretty much enter whatever file name you want. The Apple II isn't very picky about file names and ignores extensions as far as I can tell. However, I would recommend using an extension of ".house" or ".hse" just to make it easier to identify your house files later. So maybe name it something like "House1.house"

LOADING HOUSE FILES
Loading a house is also very easy. Again, go to the exterior view of the house and select "Menu" to go to the Main Menu. Select "Restore saved house." This will display a screen where the contents of the disk will be shown, and you will be prompted to enter the file name of the house you want to load. If you want to cancel, just leave it blank and press RETURN and no changes will be made.

KNOWN ISSUES
First of all, as this was my first program for the Apple II, I'm sure there are plenty of ways it could be improved! The BASIC code could probably be made much more efficient. But I've made gradual improvements to it over time, and for the moment I'm happy with it. Any suggestions are welcome and appreciated, however!

One possible issue is that when placing objects, if you move the pointer too close to the edge of the screen, it MIGHT cause an error and make the program crash. This is because the program will attempt to draw graphics that are beyond the screen. I tried to prevent this by limiting how far you can move the pointer, but errors may still be possible. To be on the safe side, be sure there is plenty of space to the left or right of the pointer. In general, the pointer indicates the middle point of trees, and the bottom left corner of objects like furniture.

Another issue is that if you use an emulator, like AppleWin, some colors might not be displayed correctly, especially red. Maybe I just need to adjust something in my installation of AppleWin? Personally, I prefer using a real Apple II computer anyway!

That should pretty much cover everything! I have included the BASIC source code in a separate folder. You are free to modify or improve the code however you want. However, if you distribute the program anywhere, such as upload it to another website, I ask that you credit my name as the original programmer. 

CONTACT
If you have any questions or suggestions, please feel free to email me!

- Christian Tobar
gatewaycityca@yahoo.com  

                   