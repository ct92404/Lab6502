Map Maker 
by Christian Tobar 
October 24, 2021
contact: gatewaycityca@yahoo.

Thank you for downloading Map Maker!

Please note that Map Maker is for DOS 3.3 - it will mostly likely NOT run on ProDos!

This is the biggest and most complex program I have written for the Apple II so far, and it was definitely a labor of love! Some things that are easy and trivial to do in a program for a modern computer are actually pretty challenging to accomplish in a vintage 8-bit computer. I had to do quite a bit of research for how to do certain things within BASIC in order to have the features I wanted. 

Included is a very thorough manual explaining everything about how to use Map Maker. (It's in PDF format as well as a .doc file, which should work in most word processing programs. I recommend Apache Open Office - it's free!). PLEASE READ THE MANUAL! Most of the features and menu options are self-explanatory, but there are some that are a little more complicated and require a couple of steps to use. They might be confusing without explanation. I covered everything in the manual, so I won't delve into that here.  

Map Maker is entirely text based, and uses text characters to draw maps. You can create your own maps from scratch - place streets, labels, locations, etc. You can name objects whatever you want. Also note that "streets" don't necessarily HAVE to be streets - you can make them trails, rivers, railroad lines, or whatever else you like. Map Maker will simply draw the line according to where you define the start and end points, and it's up to you to name it whatever you want. You can easily save your maps, and if you're using a real Apple II computer, you can also print them. It does have some limitations - it unfortunately can't draw diagnal streets. Other limitations are discussed in the manual. However, it still has a LOT of features which should be very useful! I'm very proud of Map Maker, and I hope you have as much fun using it as I did writing it!

You might wonder why bother to make a mapping program for an ancient 8-bit computer when we have extremely powerful modern programs like Google Earth? Well, first of all, most modern mapping programs do not allow you to CREATE your own maps from scratch. They are used only to view maps that have already been prepared. Map Maker can be used to make unique maps that are otherwise not available. One great use would be to create a historical map showing locations that no longer exist or are no longer shown on modern maps. Or maybe create a map for a campground or trail. Or use it to create a map for a game. There are plenty of uses and it really is open to your imagination.

And of course, the biggest reason to create a mapping program for an old 8-bit computer is for the challenge! Why do it...why not?!

USING WITH A REAL APPLE II COMPUTER
If you want to use the program with an actual vintage Apple II computer (which I definitely recommend!), you have 2 options to transfer it from your modern computer to the Apple II. You can use a serial or serial-to-usb cable and send the text from the included BASIC code with a serial connection to the Apple II.  OR you can use the included .wav sound file to transfer the program by connecting an audio cable to the Apple II "casette input" jack. The wav file includes a utility which will automatically save the BASIC program onto a floppy disk. Insert a blank disk into the Apple II disk drive, and type "LOAD" on the Apple II. Then play the .wav file. Note that there are 2 versions of the .wav file. One will format the disk first before the program is copied. The other SHOULDN'T format the disk, but I would suggest you use a blank disk to be safe! Two files will be copied onto the floppy disk - the program "Map Maker" itself, and another file named "Map Maker Config.cfg." The second file is just a text file, but it's extremely important. DO NOT delete it! It contains variables that the program will look for when it first starts. The configuration file is explained in the manual.   

If you prefer, I can also send you a real physical copy of the program. If you want just a floppy disk with the program, I ask $10. If you want both a floppy disk copy and a printed and bound manual, I ask $25. Email me if you're interested.

USING WITH AN EMULATOR
If you want to run the program on a modern computer, you will need an Apple II emulator. AppleWin is the only one I've personally used. Just load the disk image file named "Map Maker.do" on the emulator. I tested the program on AppleWin and everything seems to work correctly. If you save or load maps, the files will just be added into the disk image and can be accessed within the Map Maker program as if you were using a real floppy disk.
 
That should pretty much cover everything! I have included the BASIC source code in a separate folder. You are free to modify or improve the code however you want. However, if you distribute the program anywhere, such as upload it to another website, I ask that you credit my name as the original programmer. 

CONTACT
If you have any questions or suggestions, please feel free to email me!

- Christian Tobar
gatewaycityca@yahoo.com  

                   