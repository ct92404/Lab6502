ColorBit 
by Christian Tobar 
October 27, 2021
contact: gatewaycityca@yahoo.

Thank you for downloading ColorBit!

Please note that ColorBit is for DOS 3.3 - it will mostly likely NOT run on ProDos!

This is a neat little program to draw pictures using the low resolution mode (GR). You can manually plot pixels and draw lines by toggling a "pen" on or off and moving a pointer around on the screen. Or draw lines by setting a start and end point. There is also a "fill" option to easily change the background color of your picture. Pictures can also be easily saved and loaded. (At the moment, the program isn't able to print pictures - I haven't figured out how to do this yet!)    

USING WITH A REAL APPLE II COMPUTER
If you want to use the program with an actual vintage Apple II computer (which I definitely recommend!), you have 2 options to transfer it from your modern computer to the Apple II. You can use a serial or serial-to-usb cable and send the text from the included BASIC code with a serial connection to the Apple II.  OR you can use the included .wav sound file to transfer the program by connecting an audio cable to the Apple II "casette input" jack.  The wav file includes a utility which will automatically save the BASIC program onto a floppy disk. Insert a blank disk into the Apple II disk drive, and type "LOAD" on the Apple II. Then play the .wav file. Note that there are 2 versions of the .wav file. One will format the disk first before the program is copied. The other SHOULDN'T format the disk, but I would suggest you use a blank disk to be safe! 

When the program disk is created, there will be 2 files saved on it - the Colorbit BASIC program itself, and another file named "GRLOADSAVE.BIN" The second file is a binary file with code that is needed to load and save GR images. Do not delete it or modify it! The program will NOT work without it!

If you prefer, I can also send you a floppy disk with the program, for $10. Email me if you're interested.

USING WITH AN EMULATOR
If you want to run the program on a modern computer, you will need an Apple II emulator. AppleWin is the only one I've personally used. Just load the disk image file named "Colorbit.do" on the emulator and enter "RUN COLORBIT" as you would on a real Apple II computer. I tested the program on AppleWin and most features work correctly, with a couple of minor issures (which are discussed in the "Known Issues and Limitations" section). If you save or load pictures, the files will just be added into the disk image and can be accessed within the ColorBit program as if you were using a real floppy disk. Again, there will also be a binary file named "GRLOADSAVE.BIN," and this file is necessary for the program to work, just as with a real Apple II disk. Leave that file alone and don't delete or modify it. 

DRAWING PICTURES
You will see a menu below the image drawing area. Press the keys as shown to move the pointer around on the screen. On this first menu, DO NOT press RETURN! The program continuously reads the keyboard input and you only need to press a key. (On other menus, however, you do need to press RETURN). Press 5 to plot a single pixel on the screen. Or you can also press 6 to toggle a "pen" on or off, which will draw a continuous line as you move the pointer. Press 7 to select a different color, or press 8 to view more menu options.

Note that in the second menu, there is also a "fill" option. Use this to partially fill in an area of your picture with a color, or you can fill in the entire image area with a color if you want to make a background. The program will prompt you for start and end point (the start and end Y value on the screen) for the area that you want to fill. However, you will need to select a color first. The "fill" option just uses whatever color has been previously selected. 

Remember, on most menus, you DO have to press RETURN when making a selection. Only the first menu directly reads the keyboard keys. 

SAVING YOUR PICTURE
It's very simple to save your picture. From the first menu, press 8 to view more options. Then enter 4, and press RETURN. You will be prompted to enter a file name. If you want to cancel, just leave it blank and press RETURN and no action will be taken. If you decide to save, you can pretty much enter whatever file name you want. The Apple II isn't very picky about file names and ignores extensions as far as I can tell. However, I would recommend using an extension of ".GR" just to make it easier to identify your image files later. So maybe name it something like "PICTURE1.GR"

LOADING PICTURE FILES
Loading a picture is also very easy. From the first menu, press 8 to view more options. Then enter 5 and press RETURN to advance one more menu. Enter 2 for "LOAD IMAGE." This will display the contents of the disk and you will be prompted to enter the file name of the picture you want to load. If you want to cancel, just leave it blank and press RETURN and no changes will be made. (However I have noticed some strange behavior when canceling picture loads when running the program on the AppleWin emulator. There aren't any problems with a real Apple II computer).  

KNOWN ISSUES AND LIMITATIONS
When you load an image, the pointer will sometimes create a small "hole" in the picture the upper left corner at its starting position. You can simply move the pointer back to that spot and plot a pixel to fix it.

Another issue is that if you use an emulator, like AppleWin, some colors might not be displayed correctly, especially red. Maybe I just need to adjust something in my installation of AppleWin? Personally, I prefer using a real Apple II computer anyway!

I have also noticed some other strange behaviors when using the program on the AppleWin emulator. Sometimes, if you cancel from the prompt to load pictures, the current image will get corrupted. I haven't seen this problem when running the program on a real Apple II computer.  

As mentioned earlier, there is no option to print your pictures, since I haven't yet been able to figure out how to send graphics from the Apple II to a printer. If anyone can help with this, please let me know! 

That should pretty much cover everything! I have included the BASIC source code in a separate folder. You are free to modify or improve the code however you want. However, if you distribute the program anywhere, such as upload it to another website, I ask that you credit my name as the original programmer. 

CONTACT
If you have any questions or suggestions, please feel free to email me!

- Christian Tobar
gatewaycityca@yahoo.com  

                   