TUNES 
by Christian Tobar 
November 9, 2021
contact: gatewaycityca@yahoo.

Thank you for downloading Tunes!

This is the first sound program I've made for the Apple II! It uses BASIC as well as some machine language code. I've just started to learn machine language. I've been studying an old book - "Apple Machine Language" by Don and Kurt Inman. It's been a huge help! I first started working on this program as just a way to experiment with getting the Apple II to play different sounds and tones. But then I realized it would be more fun to see how I could get it to play short tunes or melodies! I had to learn more about music, and then I kept adding more features to the program. Finally, I finished it...and for lack of a better name, I'm calling it "TUNES"!  

I'm sure there are many ways the program could be improved. But I'm happy with it for the time being, with my limited experience.  Feel free to make any changes to the program. All I ask is that if you upload it to another website or otherwise distribute it, please credit my name as the orignal programmer and writer. 

Please note that Tunes is for DOS 3.3 - it will most likely NOT run on ProDos!

USING WITH A REAL APPLE II COMPUTER
If you want to use the program with an actual vintage Apple II computer (which I definitely recommend!), you have 2 options to transfer it from your modern computer to the Apple II. You can use a serial or serial-to-usb cable and send the text from the included BASIC code with a serial connection to the Apple II.  OR you can use the included .wav sound file to transfer the program by connecting an audio cable to the Apple II "casette input" jack. The wav file includes a utility which will automatically save the BASIC program onto a floppy disk. Insert a blank disk into the Apple II disk drive, and type "LOAD" on the Apple II. Then play the .wav file. Note that there are 2 versions of the .wav file. One will format the disk first before the program is copied. The other SHOULDN'T format the disk, but I would suggest you use a blank disk to be safe! 

If you prefer, I can also send you a floppy disk with the program, for $10. Email me if you're interested.

When the program disk is created, there will be several files saved on it.  One is the Tunes BASIC program itself.  Another is a file named "TUNES CONFIG - it contains default values for variables which the program looks for when it first starts. Do not delete or modify the TUNES CONFIG file! The program will NOT work without it! You will also see other files that end with ".TUNE" - these are samples of "songs" that the program can play. Actually, they are more like just simple melodies or tunes. The Apple II handles sound in a very crude way. It can only produce simple beeps and tones.  But it is possible to vary the frequency and duration.  By playing tones at the right frequencies, you can play musical notes! The tune files each contain a list of tones that are played in order, to produce a simple tune or melody.  More will be discussed about tune files later.

Type "RUN TUNES" to start the program. Please be patient! It's a HUGE program and will take the Apple II a little bit of time to load. (I nearly maxed out the 64kb of memory! I think there might be about 2kb of free RAM left!)   

USING WITH AN EMULATOR
If you want to run the program on a modern computer, you will need an Apple II emulator. AppleWin is the only one I've personally used. Just load the disk image file named "Tunes.do" on the emulator, and type "RUN TUNES" as you would on a real Apple II.  

CREATING TUNES
At its core, the program is designed to generate a series of tones. It isn't necessarily intended to work like an electronic organ. The tones you want to play are entered as a list, and can then be played in order. (The tones are not played in real time as you type them in).  However, you can enter tones in a wide range of frequencies, from 198 Hz all the way up to about 2000 Hz. By entering tones at the right frequencies, the program will play musical notes! 

Select "2" from the Main Menu to enter a list of tones. A prompt will first ask you how many tones you want to play. The maximum is 26. (This is enough for the basic melody of a simple song). It will then ask you to enter each tone in the order that you want to play, separated by a comma. Note however that the number you enter is NOT for the frequency! It's actually a number from 1-255 that is poked into the computer's memory. The program uses machine code and produces sounds by controlling how fast the speaker is oscillated. A lower number produces a higher pitch, a higher number produces a lower pitch. For example 170 will produce a higher pitch tone than 200. Once you have finished entering the tones you want to play, you will be taken back to the Main Menu. You can then select "1" to play the tune you have created. You can play it as many times as you want.

I have included a list at the end of this manual with tone numbers and the frequencies they correspond to. However, there is also a feature to enter in a list of musical notes so you don't have to use tedius trial-and-error and guess what tone number to enter for which note. (I already did that part!)  We will disucss entering music notes next.

When we discuss music, you will have to forgive me, as I know VERY little about it! I had to do a lot of research to try to understand some of the basics. As I understand it, musical notes are on a scale of C,B,D,E,F,G,A, and B. The letters then repeat on a higher scale starting again on C. It was extremely confusing for me that the letters would repeat, until I read that they are actually given a number. So at the lowest end would be C1,D1,E1,F1,G1,A1,B1. Then C2,D2,E2,F2,G2,A2,B2.    And so on. There are also minor "flat" notes between the major notes (the black keys on a piano). For example, a D flat is written as "Db" and flat notes also have a scale. (Except that there is no "F flat.")  The lowest flat note, on the left side of a piano, starts at Db1. So for example, Db1,Eb1,Gb1,Ab1,Bb1. Then Db2,Eb2,Gb2,Ab2,Bb2. And so on.

The major note at about the halfway point on a piano is C4, and is called "Middle C."  The scale of C4,D4,E4,F4,G4,A4,B4 is commonly used in a lot of traditional songs. It's known as the "C Major Scale." Most kids' songs, such as "Twinkle Twinkle Little Star," "Mary Had A Little Lamb," etc also use it. 

ENTERING MUSICAL NOTES
Select "3" from the Main Menu to create a tune by entering musical notes. A prompt will first ask you how many notes you want to play. Again, the maximum is 26. Enter each note in the order that you want to play, separated by a comma. Enter the notes as letters - C,D,E,F,G,A or B. Since the C Major Scale is so commonly used, the program is written so that you do NOT have to enter numbers if you are using notes from C4-B4. Simply enter the letters. This is done just to make it easier to enter the notes for traditional songs. However, if you enter any notes higher than B4, such as C5, you DO have to enter the number. Such as C5,D5,E5,F5,G5. You also must enter a complete letter and number for flat notes. For example, enter "Db4" for D4 flat. The program will recognize all notes from C4-C6. This is the "Treble Clef" or basically all the notes on the right half of a piano keyboard. The program will automatically convert the notes you entered into tone numbers so that each note will be played at the correct pitch. (Or as close as possible for an ancient 8-bit computer!) 

Unfortunately, I was not able to include notes from the bass side (B3 and lower). There just isn't enough memory! As it is, the program is massive. I found that the basic melody for most well known traditional songs used notes on the Treble Clef, so I felt that this was a fair compromise. The program CAN play lower notes (it can play sounds all the way down to 198 Hz), but you will have to enter tone numbers instead.

Tone numbers and musical notes can't be entered together. You have to use one or the other. So if you are creating a tune that is using notes lower than C4, you will have to select "2" from the Main Menu and enter tone numbers instead. (This is because the prompt to enter tone numbers is expecting a numerical value, and the prompt to enter musical notes is expecting a string value. Entering the wrong kind of input will cause errors). 

Once you have finished entering musical notes, you can play the tune by selecting "1" from the Main Menu.

CHANGING TONE DURATION
You can change how long tones are played by selecting "4" from the Main Menu. This will change the overall tempo of the tune. Enter a number from 1-255. A lower number will play tones for a shorter time. A higher number will play tones for a longer time. However, there is no way to change the duration for any one particular note. The setting will be applied for all the notes in the tune. You might want to experiment with this setting and try different numbers to get a song to sound right.

SAVING TUNE FILES
Once you create a tune (either by entering tones or entering musical notes), you can easily save it to a floppy disk. Select "5" from the Main Menu. You will then be prompted to enter a file name to save. The Apple II computer isn't very picky about file names and you can enter just about anything you want. Extensions are optional. However, I would suggest using an extension of ".TUNE" just so you can easily identify your tune files later. So maybe name the file "TUNE1.TUNE" for example. You will notice that there are several tune files already on the disk as samples which you can load and play.

The tone duration setting will also be saved in the file, so that the tune will be played at the right speed the next time you load it.

If you change your mind and want to cancel, just leave the prompt blank and press RETURN to go back to the Main Menu.

LOADING TUNE FILES
You can easily load tune files to play them again. Select "6" from the Main Menu. This will show a catalog of the files on the floppy disk, and then a prompt asking for a file name to load. You must enter the ENTIRE name of the file. So "TUNE1.TUNE" for example. There are already several samples of tune files on the disk. Try them out! My favorite songs are "Ode To Joy" and "The Entertainer"!  Since Christmas is next month, I also included a few Christams melodies!

Again, if you change your mind and want to cancel, you can just leave the prompt blank and press RETURN to go back to the Main Menu.

SAVING MUSICAL NOTES FILES
If you create a tune by entering musical notes, you can save a file with the notes. Select "7" from the Main Menu. Musical note files can be loaded and played again. The program will automatically convert them back into tone numbers. Once the notes are loaded, you can play the tune again by selecting "1" in the Main Menu. However, the tone duration setting is NOT saved in note files. You must change the tone duration, and then save the tune again as a TUNE file. The feature for musical note files was mainly added as a convenience, so that you could see the list of notes in a tune by viewing the file with a text editor. (TUNE files would just show a list of numbers and would be confusing if you tried to look at them!)  I would suggest naming musical notes files with ".NOTES" to easily identify them later and not get them confused with TUNE files. Maybe something like "TUNE1.NOTES"  

LOADING MUSICAL NOTES FILES
Select "8" from the Main Menu to load musical notes files. This will show a catalog of the files on the floppy disk, and then a prompt asking for a file name to load. You must enter the ENTIRE name of the file. So "TUNE1.NOTES" for example. Again, remember that the tone duration setting is NOT saved in note files. If you want to play the notes faster or slower, you must change the tone duration setting from the Main Menu. Then save the tune again as a TUNE file (Option "5" in the Main Menu).

CLEARING TONES AND NOTES
Select "9" from in the Main Menu if you want to start over and create a new tune. This will erase all the tones and notes currently in the memory. It's recommended that you do this before you start entering tones or notes for a new tune, but it isn't absolutely necessary.

CONFIGURE MUSICAL NOTES
I was very careful about getting the computer to play tones at the right frequency for each note. I used an online pitch detection program on my smartphone. It picks up sound from the microphone and shows the frequency and note it detected. I held the phone by the computer and played different tone numbers. I kept adjusting the tone number, and checking and re-checking the frequency until I got as close as I could to each note. I also checked it again with another program on a different website just to be sure. It was a very tedious and painstaking process! But it was worth it. The notes seem to be spot on! Or, at least as close as possible!

However, you can change the tone number that is used for each note if you want them to be played at a higher or lower pitch. Enter "10" from the Main Menu. This will then display another menu where you can enter the tone number for each note. (Remember that this is a number from 1-255, NOT a frequency!)  On this menu, you can change the pitch for all the major notes. To change the pitches for minor "flat" notes, enter "16" to go to another menu.

Remember to update the config file so that the program will keep the changes you made. Select "11" in the Main Menu.

I personally would not recommend trying to change the pitch for notes unless absolutely necessary! It's possible that your computer might sound a little different because of the condition of the speaker, or maybe you have a different taste in how notes should sound. But just be aware that it's a very tedius process! It's not hard, just very time-consuming. "Tuning" a 40 year old 8-bit computer is definitely not like tuning a guitar!    
    
CONCLUSION
That should just about cover everything! Please remember to try the sample songs included on the floppy disk (or disk image). I had a lot of fun entering those tunes, and it was neat (and hilarious!) to hear an Apple II play "Ode To Joy"!

If you have any questions or suggestions, email me at gatewaycityca@yahoo.com 

THE FOLLOWING IS A REFERENCE SHOWING THE FREQUENCIES OF NOTES, AND THE TONE VALUES WHICH CORRESPOND TO EACH NOTE.


MAJOR NOTE FREQUENCIES
B3=246 hZ
C=256 Hz
D=293 Hz
E=329 Hz
F=349 Hz
G=391 Hz
A=440 Hz
B=493 Hz
C5=523 Hz
D5 = 587 Hz
E5 = 659 Hz
F5 = 698 Hz
G5 = 783 Hz
A5 = 880 Hz
B5 = 987 Hz
C6 = 1046 Hz

MINOR NOTES FREQUENCIES 
Db4 = 277 Hz
Eb4 = 311 Hz
Gb4 = 369 Hz
Ab4 = 415 Hz
Bb4 = 466 Hz
Db5 = 554 Hz
Eb5 = 622 Hz
Gb5 = 739 Hz
Ab5 = 830 Hz
Bb5 = 932 Hz


COMPUTER TONE VALUES FOR NOTES

* B3 is listed here as a convenience. The program will not recognize any notes lower than C4. You have to enter tone numbers to play lower notes. 

204=246 Hz (B3)
198=256 Hz (C)
172=293 Hz (D)
153=329 Hz (E) 
144=349 Hz (F)
129=391 Hz (G)
114=440 Hz (A)
102=493 Hz (B)
96=525 Hz (C5)
86=587 Hz (D5)
77=659 Hz (E5)
72=698 Hz (F5)
64=783 Hz (G5)
57=880 Hz (A5)
51=987 Hz (B5)
48=1046 Hz (C6)
183=277 Hz (Db4)
163=311 Hz (Eb4)
137=369 Hz (Gb4)
122=415 Hz (Ab4)
108=466 Hz (Bb4)
91=554 Hz (Db5)
81=622 Hz (Eb5)
68=739 Hz (Gb5)
60=830 Hz (Ab5)
53=932 Hz (Bb5)


ALL COMPUTER TONE VALUES

* Tones between these numbers will also work. This is just to give you a "ballpark idea" of what tone numbers to use if you want to play a certain sound frequency.

25=2000 Hz
50=1000 Hz
55=910 Hz
60=834 Hz
65=772 Hz
70=718 Hz
75=671 Hz
80=629 Hz
85=592 Hz
90=560 Hz
95=531 Hz
100=504 Hz
105=480 Hz
110=458 Hz
115=439 Hz
120=421 Hz
125=404 Hz
130=388 Hz
135=374 Hz
140=361 Hz
145=348 Hz
150=337 Hz
155=326 Hz
160=316 Hz
165=306 Hz
170=298 Hz
175=289 Hz
180=281 Hz
185=273 Hz
190=266 Hz
195=259 Hz
200=253 Hz
205=247 Hz
210=241 Hz
215=233 Hz
220=230 Hz
225=225 Hz
230=220 Hz
235=215 Hz
240=211 Hz
245=207 Hz
250=202 Hz
255=198 Hz




  


  






  
      